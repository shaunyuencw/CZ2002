public class MyFirstProgram{
    public static void main(String[] args) throws Exception {
        System.out.println("Hello! This is my first program.");
        System.out.println("Bye Bye!");
    }
}
